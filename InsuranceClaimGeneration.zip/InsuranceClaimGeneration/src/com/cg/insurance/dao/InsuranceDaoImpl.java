package com.cg.insurance.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;


import com.cg.insurance.bean.AccountBean;
import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.client.InsuranceMain;
import com.cg.insurance.exception.InsuranceClaimException;
import com.cg.insurance.util.DbConnection;


public class InsuranceDaoImpl implements  IInsuranceDAO {
static UserBean userBean=null;
static Connection connection=null;


static QuestionBean questionBean = new QuestionBean();
static ClaimBean claimBean = new ClaimBean();
static AccountBean accountBean=null;
static PolicyDetailsBean policyDetailsBean=null;
static InsuranceMain insuranceMain=null;
static Logger logger = Logger.getLogger(InsuranceMain.class);

	@Override
	public String checkAccess(UserBean userbean) throws IOException, SQLException, InsuranceClaimException {
		logger.info("in checkAccess");
		PreparedStatement statement=null;
		String message=null;
		String user=null;
		String pass = null;
		String role =null;
		try {
			 connection = DbConnection.getConnection();
			 
			 statement=connection.prepareStatement(QueryMappers.checkAccess);
			 statement.setString(1,userbean.getUsername());
			 //statement.executeUpdate();
			 
			
			 ResultSet resultSet = statement.executeQuery();
			 while(resultSet.next()) {
				 user = resultSet.getString(1);
				 pass = resultSet.getString(2);
				 role = resultSet.getString(3);
			 }
			
			 if(user!=null) {
					if(pass.equals(userbean.getPassword())) {
						return role;
					}
					else {
						message="wrong password";
						//throw new InsuranceClaimException("wrong password");
					}
			 }
			 else {
				 message="NO such User Exists!!";
				 	//throw new InsuranceClaimException("NO such User Exists!!");
				 
				}
			 if(message!=null) {
				 throw new InsuranceClaimException(message);
			 }
			 
			
		} catch (NullPointerException e) {
			logger.error(" " + e.getMessage());
			throw new InsuranceClaimException("There are no records of User");
		}
		finally
		{
				try 
				{
					statement=null;
					userbean=null;
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(" " + sqlException.getMessage());
					throw new InsuranceClaimException("Error in closing db connection");

				}
		}
		return null;
	}

	@Override
	public void addUser(UserBean userbean) throws InsuranceClaimException, IOException {
		logger.info("in addUser");
		connection = DbConnection.getConnection();
		PreparedStatement pst = null;
		
		
		try {
			
			pst = connection.prepareStatement(QueryMappers.insert_User);
			pst.setString(1,userbean.getUsername());
			pst.setString(2,userbean.getPassword());
			pst.setString(3,userbean.getRoleCode());
			
			
			pst.executeUpdate();
			
		}
		catch(SQLException sqlException)
		{
			logger.error(" " + sqlException.getMessage());
				throw new InsuranceClaimException("Problem in Inserting Project in database!!");
		}
			
		finally
		{
				try 
				{
					
					pst.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					
					logger.error(" " + sqlException.getMessage());
					throw new InsuranceClaimException("Error in closing db connection");

				}
		}
		
	}

	@Override
	public List<ClaimBean> viewAllClaims(String userName) throws InsuranceClaimException, IOException, SQLException {
		logger.info("in viewAllClaims");
		connection = DbConnection.getConnection();
		String name = null;
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(QueryMappers.selectQuery);
		while (resultSet.next()) {
			name = resultSet.getString(1);

			if (userName.equals(name)) {
				name = userName;
				break;
			}

		}

		List<ClaimBean> claimList = new ArrayList<ClaimBean>();
		if (userName.equals(name)) {
			try {
				PreparedStatement ps = connection.prepareStatement(QueryMappers.viewAllClaims);
				ps.setString(1, name);
				ps.executeUpdate();
				resultSet = ps.executeQuery();
				if (resultSet == null) {
					throw new InsuranceClaimException("There are no claims...");
				} else {
					while (resultSet.next()) {
						ClaimBean claim = new ClaimBean();
						claim.setClaimNumber(resultSet.getString(1));
						claim.setClaimType(resultSet.getString(2));
						claim.setPolicyNumber(resultSet.getLong(3));
						claimList.add(claim);
					}
					return claimList;
				}
			} catch (Exception e) {
				logger.error(" " + e.getMessage());
				throw new InsuranceClaimException("problem has occured");
			}
			finally {
				connection.close();
			}
			
			} else {
			
			throw new InsuranceClaimException("user name is not found");
		}
		// return claimList;

	}

	@Override
	public List<PolicyBean> viewAllPolicy(String userName) throws IOException, InsuranceClaimException, SQLException {
		logger.info("in viewAllPolicy");
		connection = DbConnection.getConnection();
		String name2 = null;
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(QueryMappers.selectQuery);
		while (resultSet.next()) {
			name2 = resultSet.getString(1);

			if (userName.equals(name2)) {
				name2 = userName;
				break;
			}

		}

		List<PolicyBean> policyList = new ArrayList<PolicyBean>();
		if (userName.equals(name2)) {
			try {
				PreparedStatement ps = connection.prepareStatement(QueryMappers.viewAllPolicies);
				ps.setString(1, name2);
				ps.executeUpdate();
				ResultSet rs = ps.executeQuery();
				if (rs == null) {
					throw new InsuranceClaimException("THERE IS NO POLICY ASSOCIATED WITH THAT USER");
				} else {
					while (rs.next()) {
						PolicyBean policy = new PolicyBean();
						policy.setPolicyNumber(rs.getLong(1));
						policy.setPolicyPremium(rs.getDouble(2));
						policy.setAccountNumber(rs.getLong(3));
						policyList.add(policy);

					}
					return policyList;
				}

			} catch (Exception e) {
				logger.error(" " + e.getMessage());
				throw new InsuranceClaimException("problem has occured in View All Policy method");
			} finally {
				connection.close();
			}
		}
		else {
			throw new InsuranceClaimException("user name is not found");
		}

	}

	@Override
	public List<AgentUserBean> fetchUsers(String name) throws IOException, InsuranceClaimException, SQLException {
		logger.info("in fetchUsers");
		Connection connection = DbConnection.getConnection();
		ResultSet resultSet = null;
		
		List<AgentUserBean> agentUserList = new ArrayList<>();
		
			try {
				PreparedStatement ps = connection.prepareStatement(QueryMappers.fetch_USer);
				ps.setString(1, name);
				ps.executeUpdate();
				resultSet = ps.executeQuery();
				if (resultSet == null) {
					throw new InsuranceClaimException("You Have No Customers....");
				} else {
					while (resultSet.next()) {
						AgentUserBean agentUserBean = new AgentUserBean();
						agentUserBean.setAgentID(resultSet.getString(1));
						agentUserBean.setUserID(resultSet.getString(2));
						agentUserList.add(agentUserBean);
					}
					return agentUserList;
				}
			}catch(SQLException sqlException)
		{
				logger.error(" " + sqlException.getMessage());
				throw new InsuranceClaimException("Problem in Fetching Users from database!!");
		}
			
		finally
		{
				try 
				{
					resultSet.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(" " + sqlException.getMessage());
					
					throw new InsuranceClaimException("Error in closing db connection");

				}
		}
		
	
	}

	

	@Override
	public List<QuestionBean> getQuestions(String businessSegment)throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException {
		logger.info("in getQuestions");
		connection = DbConnection.getConnection();
		PreparedStatement preparedStatement = null;

		ResultSet resultSet = null;

		try {
			preparedStatement = connection.prepareStatement(QueryMappers.EXECUTE_QUERY);
			preparedStatement.setString(1, businessSegment);
			resultSet = preparedStatement.executeQuery();
			List<QuestionBean> list = new ArrayList<>();
			// Iterator<QuestionBean> iterator = list.iterator();
			while (resultSet.next()) {
				questionBean = new QuestionBean();
				questionBean.setQuestionId(resultSet.getString(1));
				questionBean.setBusinessSegment(resultSet.getString(2));
				questionBean.setQuestionNo(resultSet.getInt(3));
				questionBean.setQuestion(resultSet.getString(4));
				questionBean.setAnswer1(resultSet.getString(5));
				questionBean.setAnswerWeightage1(resultSet.getInt(6));
				questionBean.setAnswer2(resultSet.getString(7));
				questionBean.setAnswerWeightage2(resultSet.getInt(8));
				questionBean.setAnswer3(resultSet.getString(9));
				questionBean.setAnswerWeightage3(resultSet.getInt(10));

				list.add(questionBean);
			}

			return list;
		} catch (SQLException sqlException) {
			logger.error(" " + sqlException.getMessage());
			throw new InsuranceClaimException("Problem in Fetching Business Segment from database!!");
		}

		finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException sqlException) {
				logger.error(" " + sqlException.getMessage());
				throw new InsuranceClaimException("Error in closing db connection");

			}
		}

	}

	@Override
	public String createClaim(ClaimBean claimBean,List<PolicyDetailsBean> policyDetailsList) throws InsuranceClaimException, ClassNotFoundException, IOException, SQLException
	{
		logger.info("in claimBean");
		PreparedStatement statement=null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		Statement st =null;
		
		try {
			
			String claimNumber = claimBean.getClaimNumber();
			connection = DbConnection.getConnection();
			connection.setAutoCommit(false);
			st = connection.createStatement();

			resultSet = st.executeQuery(QueryMappers.GEN_SEQ);

			while (resultSet.next()) {
				claimNumber += resultSet.getString(1);
			}

			statement = connection.prepareStatement(QueryMappers.CHECK_CLAIM_USING_POLICY_NO);
			statement.setLong(1, claimBean.getPolicyNumber());

			resultSet1= statement.executeQuery();
			
			if (!resultSet1.next()) {
				PreparedStatement statement1 = connection.prepareStatement(QueryMappers.INSERT_CLAIM);
				statement1.setString(1, claimNumber);
				statement1.setString(2, claimBean.getClaimReason());
				statement1.setString(3, claimBean.getAccidentLocationStreet());
				statement1.setString(4, claimBean.getAccidentCity());
				statement1.setString(5, claimBean.getAccidentState());
				statement1.setString(6, claimBean.getAccidentZip());
				statement1.setString(7, claimBean.getClaimType());
				statement1.setLong(8, claimBean.getPolicyNumber());
				statement1.executeUpdate();
				
				
				Iterator<PolicyDetailsBean> iterator = policyDetailsList.iterator();
				
				while(iterator.hasNext())
				{
					policyDetailsBean = new PolicyDetailsBean();
					policyDetailsBean=iterator.next();
					PreparedStatement statement2 = connection.prepareStatement(QueryMappers.INSERT_POLICY_DETAILS);
					statement2.setLong(1,policyDetailsBean.getPolicyNumber());
					statement2.setString(2, policyDetailsBean.getQuestionId());
					statement2.setString(3,policyDetailsBean.getAnswer());
					statement2.executeUpdate();
				}
				
				connection.commit();
				return claimNumber;
			} else {
				throw new InsuranceClaimException("You Can Claim only once per Policy");
			}
		} catch (SQLException sqlException) {
			logger.error(" " + sqlException.getMessage());
			connection.rollback();
			throw new InsuranceClaimException("Problem in Inserting CLaim and Policy details in database!!");
		} finally {
			try {
				//statement1.close();
				statement.close();
				resultSet1.close();
				resultSet.close();
				st.close();
				connection.close();
			} catch (SQLException sqlException) {

				logger.error(" " + sqlException.getMessage());
				throw new InsuranceClaimException("Error in closing Resources");

			}
		}

	}

	@Override
	public String getBusinessSegment(String name) throws ClassNotFoundException, IOException, SQLException, InsuranceClaimException {
		
		logger.info("in getBusinessSegment");
		Connection connection = DbConnection.getConnection();
		PreparedStatement preparedStatement=null;
		String business=null;
		ResultSet resultSet=null;
		//accountBean=new AccountBean();
		try
		{
			preparedStatement = connection.prepareStatement(QueryMappers.Get_BusinessSegment);
			preparedStatement.setString(1, name);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next())
			{
				business=resultSet.getString(1);
			}
			return business;
		}
		catch(SQLException sqlException)
		{
			logger.error(" " + sqlException.getMessage());
				throw new InsuranceClaimException("Problem in Fetching Business Segment from database!!");
		}
			
		finally
		{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{	logger.error(" " + sqlException.getMessage());
					throw new InsuranceClaimException("Error in closing db connection");

				}
		}
		
		
	}
	
	
	
	

}
