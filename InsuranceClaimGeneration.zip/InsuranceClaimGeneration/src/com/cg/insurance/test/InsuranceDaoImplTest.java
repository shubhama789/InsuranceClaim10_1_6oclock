package com.cg.insurance.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.insurance.bean.AgentUserBean;
import com.cg.insurance.bean.ClaimBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.QuestionBean;
import com.cg.insurance.bean.UserBean;

public class InsuranceDaoImplTest {

	@Test
	public void testCheckAccess() {
		UserBean userBean=new UserBean();
		userBean.getUsername();
		userBean.getPassword();
		userBean.getRoleCode();
	}

	@Test
	public void testAddUser() {
		UserBean userBean=new UserBean();
		userBean.setUsername("USER001");
		userBean.setPassword("001user");
		userBean.setRoleCode("USER");
	}

	@Test
	public void testViewAllClaims() {
		ClaimBean claimBean=new ClaimBean();
		claimBean.getClaimReason();
		claimBean.getAccidentLocationStreet();
		claimBean.getAccidentCity();
		claimBean.getAccidentState();
		claimBean.getAccidentZip();
		claimBean.getClaimNumber();
		claimBean.getClaimReason();
		claimBean.getPolicyNumber();
	}

	@Test
	public void testViewAllPolicy() {
		PolicyBean policyBean=new PolicyBean();
		policyBean.getAccountNumber();
		policyBean.getPolicyNumber();
		policyBean.getPolicyPremium();
	}

	@Test
	public void testFetchUsers() {
		AgentUserBean agentUserBean=new AgentUserBean();
		agentUserBean.getAgentID();
		agentUserBean.getUserID();
	}

	@Test
	public void testGetQuestions() {
		QuestionBean questionBean=new QuestionBean();
		questionBean.getQuestion();
	}

	@Test
	public void testCreateClaim() {
		ClaimBean claimBean=new ClaimBean();
		claimBean.setClaimReason("accident");
		claimBean.setAccidentLocationStreet("ramanthapur");
		claimBean.setAccidentCity("hyderabad");
		claimBean.setAccidentState("telengana");
		claimBean.setAccidentZip("500013");
		claimBean.setPolicyNumber(1000101);
	}

	@Test
	public void testGetBusinessSegment() {
		QuestionBean questionBean=new QuestionBean();
		questionBean.getBusinessSegment();
		
	}

}
